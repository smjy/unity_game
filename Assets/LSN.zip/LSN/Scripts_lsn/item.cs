﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class item : MonoBehaviour {
    public bool stackable;
    public Sprite sprite;
    public string description;
	// Use this for initialization
	void Start () {
        // sprite = GetComponent<Image>().sprite;
        description = "ksfjsdfjljfalk";
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
